package com.einfochips.listenerservice.client;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;



@Component
public class BatchServiceClient {

	@Autowired
	RestTemplate restTemplate;


	public String updateDeviceStatus(String deviceId, String status) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("deviceId", deviceId);
		params.put("status", status);
		ResponseEntity<String> restExchange = restTemplate.exchange(
				"http://BATCH-SERVICE/updateDevice/{deviceId}/{status}", HttpMethod.PUT, null, String.class, params);
		return restExchange.getBody();
	}
	
}
