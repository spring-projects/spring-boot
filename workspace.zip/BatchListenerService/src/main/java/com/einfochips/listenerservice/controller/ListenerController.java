package com.einfochips.listenerservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.einfochips.listenerservice.service.ListenerService;

@RestController
public class ListenerController {

	@Autowired
	ListenerService listenerService;
	@PutMapping("/statusFromDevice/{deviceId}/{status}")
	ResponseEntity<String> updateDeviceStatus(@PathVariable("deviceId") String deviceId,
			@PathVariable("status") String status) {
		listenerService.updateDeviceStatus(deviceId,status);
		return new ResponseEntity<>("Device status updated", HttpStatus.OK);

	}

}
