package com.einfochips.listenerservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.einfochips.listenerservice.client.BatchServiceClient;

@Service
public class ListenerService {
	@Autowired
	BatchServiceClient batchServiceClient;

	public void updateDeviceStatus(String deviceId, String status) {
		batchServiceClient.updateDeviceStatus(deviceId, status);

	}

}
