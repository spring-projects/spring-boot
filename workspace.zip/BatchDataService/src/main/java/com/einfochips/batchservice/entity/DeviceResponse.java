package com.einfochips.batchservice.entity;

import java.util.List;

public class DeviceResponse {
	
	List<DeviceDetails> deviceLst;

	public List<DeviceDetails> getDeviceLst() {
		return deviceLst;
	}

	public void setDeviceLst(List<DeviceDetails> deviceLst) {
		this.deviceLst = deviceLst;
	}

	public DeviceResponse(List<DeviceDetails> deviceLst) {
		super();
		this.deviceLst = deviceLst;
	}
	
	

}
