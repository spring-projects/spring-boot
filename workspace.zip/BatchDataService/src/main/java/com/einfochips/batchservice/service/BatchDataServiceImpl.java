package com.einfochips.batchservice.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.einfochips.batchservice.entity.DeviceDetails;
import com.einfochips.batchservice.repository.DeviceDetailRepository;

@Service
public class BatchDataServiceImpl implements BatchDataService{

	
	@Autowired
	DeviceDetailRepository repository;
	
	@Override
	public String fetchBatchChunk() {
		LocalDate dt = LocalDate.now();
		System.out.println("date"+dt);
		return repository.getBatchChunk(dt);
	}

	@Override
	public List<DeviceDetails> getDeviceListForChunk(int chunkId) {
		return repository.findAllDevicesByChunkID(chunkId);
	}

	@Override
	public void updateDeviceStatusForChunk(int chunkId) {
		DeviceDetails ddetl = new DeviceDetails();
		ddetl.setChunkId(""+chunkId);
		ddetl.setStatusOfUpgrade(true);
		repository.update(ddetl);
		
	}

	@Override
	public void updateDeviceStatus(String deviceId, String status) {
		boolean deviceStatus= Boolean.valueOf(status);
		repository.updateDeviceStatus(deviceId,deviceStatus);
	}

}
