package com.einfochips.batchservice.entity;

import java.util.Date;

public class BatchDetails {
	 
	private String chunkId;	   
	private Date scheduledDate;
	
	public String getChunkId() {
		return chunkId;
	}
	public void setChunkId(String chunkId) {
		this.chunkId = chunkId;
	}
	public Date getScheduledDate() {
		return scheduledDate;
	}
	public void setScheduledDate(Date scheduledDate) {
		this.scheduledDate = scheduledDate;
	}	 

}
