package com.einfochips.batchservice.service;

import java.util.List;



import com.einfochips.batchservice.entity.DeviceDetails;

public interface BatchDataService {

	String fetchBatchChunk();

	List<DeviceDetails> getDeviceListForChunk(int chunkId);

	void updateDeviceStatusForChunk(int chunkId);

	void updateDeviceStatus(String deviceId, String status);

	

}
