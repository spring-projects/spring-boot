package com.einfochips.batchservice.controller;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;
import com.einfochips.batchservice.entity.DeviceDetails;
import com.einfochips.batchservice.entity.DeviceResponse;
import com.einfochips.batchservice.service.BatchDataService;

@RestController
public class BatchDataController {

	@Autowired
	BatchDataService batchDataService;

	@GetMapping("/fetchBatchChunk")
	ResponseEntity<String> getChunkid() {

		String chunkid = batchDataService.fetchBatchChunk();
		return new ResponseEntity<>(chunkid, HttpStatus.OK);

	}

	@GetMapping("/fetchDeviceList/{chunkId}")
	ResponseEntity<DeviceResponse> getDeviceListForChunk(@PathVariable("chunkId") int chunkId) {
		List<DeviceDetails> deviceList = Collections.EMPTY_LIST;
		deviceList = batchDataService.getDeviceListForChunk(chunkId);

		return new ResponseEntity<>(new DeviceResponse(deviceList), HttpStatus.OK);

	}

	@PutMapping("/upgrade/{chunkId}")
	ResponseEntity<String> updateDeviceStatusForChunk(@PathVariable("chunkId") int chunkId) {
		batchDataService.updateDeviceStatusForChunk(chunkId);
		return new ResponseEntity<>("Device status updated", HttpStatus.OK);

	}

	@PutMapping("/updateDevice/{deviceId}/{status}")
	ResponseEntity<String> updateDeviceStatus(@PathVariable("deviceId") String deviceId,
			@PathVariable("status") String status) {
		batchDataService.updateDeviceStatus(deviceId, status);
		return new ResponseEntity<>("Device status updated", HttpStatus.OK);

	}
	

}
