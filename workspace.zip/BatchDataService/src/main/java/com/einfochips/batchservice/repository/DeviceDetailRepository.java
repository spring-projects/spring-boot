package com.einfochips.batchservice.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.einfochips.batchservice.entity.DeviceDetails;

@Repository
public class DeviceDetailRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	

	class DeviceDtlRowMapper implements RowMapper<DeviceDetails> {
		@Override
		public DeviceDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
			DeviceDetails deviceDetails = new DeviceDetails();
			deviceDetails.setDeviceId(rs.getString("DEVICEID"));
			deviceDetails.setChunkId(rs.getString("CHUNKID"));
			deviceDetails.setStatusOfUpgrade(rs.getBoolean("UPGRADESTATUS"));
			return deviceDetails;
		}

	}

	public List<DeviceDetails> findAllDevicesByChunkID(int chunkId) {
		return jdbcTemplate.query("select * from DEVICEDETAIL WHERE CHUNKID = ?", new Object[] { chunkId },
				new DeviceDtlRowMapper());
	}


	

	public int update(DeviceDetails deviceDetails) {
		return jdbcTemplate.update("update DEVICEDETAIL " + " set UPGRADESTATUS = ? where CHUNKID = ?",
				new Object[] { deviceDetails.getStatusOfUpgrade(), deviceDetails.getChunkId() });
	}




	public String getBatchChunk(LocalDate dt) {
		//System.out.println("select CHUNKID from BATCHDETAILS WHERE SCHEDULEDDATE =" +dt);
		return jdbcTemplate.queryForObject("select CHUNKID from BATCHDETAILS WHERE SCHEDULEDDATE = ?", new Object[] { dt },
				String.class);
	}




	public int updateDeviceStatus(String deviceId, Boolean status) {
		return jdbcTemplate.update("update DEVICEDETAIL " + " set UPGRADESTATUS = ? where DEVICEID = ?",
				new Object[] { status, deviceId });
		
	}
}
