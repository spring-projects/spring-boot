package com.einfochips.batchservice.entity;

public class DeviceDetails {
	
private String	deviceId ;
private	String chunkId; 
private	Boolean statusOfUpgrade ;


public String getDeviceId() {
	return deviceId;
}
public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
}
public String getChunkId() {
	return chunkId;
}
public void setChunkId(String chunkId) {
	this.chunkId = chunkId;
}
public Boolean getStatusOfUpgrade() {
	return statusOfUpgrade;
}
public void setStatusOfUpgrade(Boolean statusOfUpgrade) {
	this.statusOfUpgrade = statusOfUpgrade;
}


}
