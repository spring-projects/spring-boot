package com.einfochips.orchetratorservice.client;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;



@Component
public class BatchServiceClient {

	@Autowired
	RestTemplate restTemplate;

	public String fetchBatchChunk() {
		String url = "http://BATCH-SERVICE/fetchBatchChunk";
		ResponseEntity<String> result = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
		return result.getBody();

	}

}
