package com.einfochips.orchetratorservice.service;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.einfochips.orchetratorservice.client.BatchServiceClient;
import com.einfochips.orchetratorservice.client.ExecutorServiceClient;

@Component
public class OrchetratorService implements ApplicationRunner {
	@Autowired
	BatchServiceClient batchServiceClient;

	@Autowired
	ExecutorServiceClient executorServiceClient;

	@Override
	public void run(ApplicationArguments args) throws Exception {
		String chunkId = batchServiceClient.fetchBatchChunk();

		executorServiceClient.doBatchProcessing(chunkId);
	}

}
