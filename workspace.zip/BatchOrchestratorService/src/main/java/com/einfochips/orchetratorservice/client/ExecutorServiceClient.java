package com.einfochips.orchetratorservice.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;



@Component
public class ExecutorServiceClient {
	@Autowired
	RestTemplate restTemplate;

	public String doBatchProcessing(String chunkId) {
		ResponseEntity<String> restExchange = restTemplate.exchange(
				"http://EXECUTOR-SERVICE/upgrade/{chunkId}", HttpMethod.GET, null, String.class, chunkId);
		return restExchange.getBody();
	}

}
