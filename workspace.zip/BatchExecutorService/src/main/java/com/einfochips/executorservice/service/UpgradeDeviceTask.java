package com.einfochips.executorservice.service;

import java.util.concurrent.Callable;

import com.einfochips.executorservice.entity.DeviceDetails;

public class UpgradeDeviceTask implements Callable<DeviceDetails> {

	private DeviceDetails deviceDetails;
	
	@Override
	public DeviceDetails call() throws Exception {
		System.out.println("Device with device Id"+deviceDetails.getDeviceId() +"Updated");
		deviceDetails.setStatusOfUpgrade(true);
		return deviceDetails;
	}

	public UpgradeDeviceTask(DeviceDetails deviceDetails) {
		super();
		this.deviceDetails = deviceDetails;
	}

	
}
