package com.einfochips.executorservice.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.einfochips.executorservice.client.BatchServiceClient;
import com.einfochips.executorservice.entity.DeviceDetails;
import com.einfochips.executorservice.entity.DeviceResponse;

@Service
public class BatchExecutorServiceImpl implements BatchExecutorService {

	@Autowired
	BatchServiceClient batchServiceClient;

	@Override
	public void doBatchProcessing(String chunkId) {

		DeviceResponse response = batchServiceClient.getDeviceDetails(chunkId);

		List<DeviceDetails> deviceLst = response.getDeviceLst();
		for (DeviceDetails deviceDetails : deviceLst) {
			System.out.println("DeviceId" + deviceDetails.getDeviceId());
		}

		List<Future<DeviceDetails>> list = new ArrayList<Future<DeviceDetails>>();
		
		ExecutorService executorService = Executors.newFixedThreadPool(30);

		for (DeviceDetails deviceDetails : deviceLst) {
			Future<DeviceDetails> future = executorService.submit(new UpgradeDeviceTask(deviceDetails));
			list.add(future);
		}
      //put message to MQ
		updateDeviceStatus(list);
		// shut down the executor service now
		executorService.shutdown();
	}

	private void updateDeviceStatus(List<Future<DeviceDetails>> list) {
		for (Future<DeviceDetails> fut : list) {
			try {
				DeviceDetails deviceDetail = fut.get();
				batchServiceClient.updateDeviceStatus(deviceDetail.getDeviceId(),
						"" + deviceDetail.getStatusOfUpgrade());
			} catch (InterruptedException | ExecutionException e) {
				e.printStackTrace();
			}
		}
	}

}
