package com.einfochips.executorservice.client;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


import com.einfochips.executorservice.entity.DeviceResponse;
@Component
public class BatchServiceClient {

	@Autowired
	RestTemplate restTemplate;

	public DeviceResponse getDeviceDetails(String chunkId) {
		ResponseEntity<DeviceResponse> restExchange = restTemplate.exchange(
				"http://BATCH-SERVICE/fetchDeviceList/{chunkId}", HttpMethod.GET, null, DeviceResponse.class, chunkId);
		return restExchange.getBody();
	}

	public String updateDeviceStatus(String deviceId, String status) {
		Map<String, String> params = new HashMap<String, String>();
		params.put("deviceId", deviceId);
		params.put("status", status);
		ResponseEntity<String> restExchange = restTemplate.exchange(
				"http://BATCH-SERVICE/updateDevice/{deviceId}/{status}", HttpMethod.PUT, null, String.class, params);
		return restExchange.getBody();
	}
	
}
