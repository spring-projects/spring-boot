package com.einfochips.executorservice.service;

public interface BatchExecutorService {

	void doBatchProcessing(String chunkId);

}
