package com.einfochips.executorservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.einfochips.executorservice.service.BatchExecutorService;

@RestController
public class ExecutorController {
	
	@Autowired
	BatchExecutorService batchExecutorService;
	
	        @GetMapping("/upgrade/{chunkId}")
			ResponseEntity<String> batchProcessing(@PathVariable("chunkId") String chunkId) {

	        	batchExecutorService.doBatchProcessing(chunkId);
				return new ResponseEntity<>("Batch Processing for Chunk id "+chunkId +"Completed", HttpStatus.OK);

			}
}
